# GuitarSori
Library for using electric guitar as input device.

- It use portaudio(http://www.portaudio.com/) / rtgraph library(https://github.com/ssepulveda/RTGraph) now.
